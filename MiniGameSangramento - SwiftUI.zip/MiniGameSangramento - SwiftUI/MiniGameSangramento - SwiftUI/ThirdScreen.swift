//
//  SegurarNariz.swift
//  miniGameSangramento
//
//  Created by Juliana Prado on 10/11/20.
//

import Foundation
import SpriteKit

class ThirdScreen: SKScene{
    //Nose node
    var nose: SKSpriteNode!
    
    //Current node touched
    private var currentNode: SKNode?
    
    //Default position of the current touched node
    private var defaultPosition: CGPoint?
    
    //Checks if user is pinching
    var pinching = false
    var timer = Timer()
    var totalTime = 10
    
    var delta = 0.0
    
    //label node
    var labelNode: SKLabelNode!
    
    //Pinch recognizer
    var pinchRec: UIPinchGestureRecognizer!
    
    var gameController = GameController.shared
    
    override func didMove(to view: SKView) {
        gameController.presentBar = true

        //Setting up nose asset on screen
        let nose = SKSpriteNode(imageNamed: "nose")
        nose.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        nose.setScale(0.75)
        nose.position = CGPoint(x: self.frame.midX, y: self.frame.midY)
        self.addChild(nose)
        
        
        //setting up labelNode
        labelNode = SKLabelNode()
        labelNode.text = "Comprima a ponta do nariz por 10 minutos."
        labelNode.position = CGPoint(x: self.size.width/2, y: self.frame.height/1.20 )
        labelNode.verticalAlignmentMode = .top
        labelNode.lineBreakMode = .byWordWrapping
        labelNode.numberOfLines = 4
        labelNode.preferredMaxLayoutWidth = 300
        self.addChild(labelNode)
        
        //Setting up the pinch recognizer
        pinchRec = UIPinchGestureRecognizer()
        pinchRec.addTarget(self, action: #selector(ThirdScreen.pinched))
        self.view!.addGestureRecognizer(pinchRec)
    }
    
    //Check if the touch the user made was on a node and gets info of the node
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let location = touch.location(in: self)
            
            let touchedNodes = self.nodes(at: location)
            
            for node in touchedNodes.reversed(){
                if node == nose{
                    self.defaultPosition = node.position
                    self.currentNode = node
                }
            }
        }
    }
    
    //Called everytime to update variables values
    override func update(_ currentTime: TimeInterval) {
        if pinching == true && currentNode == nose{
            if GameController.shared.barProgress >= 100 && !GameController.shared.actionFinished{
                
                GameController.shared.actionFinished = true
                
                //Setting label to show progression
                if let label = self.childNode(withName: "labelNode") as? SKLabelNode {
                    label.verticalAlignmentMode = .top
                    label.text = "Isso!"
                    label.lineBreakMode = .byWordWrapping
                    label.numberOfLines = 4
                    label.preferredMaxLayoutWidth = 350
                }
                let seconds = 2.0
                //Calling next scene
                DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
                    let goToNextScene = NarizScene4(size: self.size)
                    GameController.shared.actionFinished = false
                    goToNextScene.scaleMode = .aspectFill
                    let transition = SKTransition.fade(with: SKColor.black, duration: 0.5)
                    self.view?.presentScene(goToNextScene, transition: transition)
                }
            } else{
                GameController.shared.barProgress += 10
            }
        }
    }
    
    //Check if the touched ended
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.currentNode?.position = self.defaultPosition ?? CGPoint(x: 0, y: 0)
        self.currentNode = nil
    }
    
    @objc func pinched(){
        pinching = true
    }
    
}
