//
//  Utilities.swift
//  MiniGameSangramento - SwiftUI
//
//  Created by Juliana Prado on 23/11/20.
//

import SpriteKit

let utilities = Utilities()



//Created this class in order to use common functions for different uses
class Utilities {
    
    
    func flashingElements(skNodes: [SKNode], duration: TimeInterval){

        let fadeIn = SKAction.fadeIn(withDuration: duration)
        let fadeOut = SKAction.fadeOut(withDuration: duration)
        let sequence = SKAction.sequence([fadeIn, fadeOut])
        
        for node in skNodes {
            print(node)
            if node.userData?.value(forKey: "isDraggable") as? Bool == true{
            
                node.run(.repeatForever(sequence))
            }
        }
    }
    
    func removeActions(nodes: [SKNode]){
        for node in nodes{
            node.removeAllActions()
            node.alpha = 1
        }
        
    }
}
