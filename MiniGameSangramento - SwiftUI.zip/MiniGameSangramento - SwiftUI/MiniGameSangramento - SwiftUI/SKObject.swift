//
//  SKObject.swift
//  MiniGameSangramento - SwiftUI
//
//  Created by Juliana Prado on 23/11/20.
//


import SpriteKit


class SKObject: SKSpriteNode{
    var isDraggable: Bool
    
    init(isDraggable: Bool, imageNamed: String) {
        self.isDraggable = isDraggable
        let texture = SKTexture(imageNamed: imageNamed)
        super.init(texture: texture, color: UIColor.clear, size: texture.size())
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
