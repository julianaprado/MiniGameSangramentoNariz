//
//  GameView.swift
//  miniGameSangramento
//
//  Created by Vitor Krau on 19/11/20.
//

import SwiftUI
import SpriteKit
import GameplayKit

struct GameView: View {
    var scene: SKScene{
        if let scene = GKScene(fileNamed: "FirstScreen"){
            if let sceneNode = scene.rootNode as! FirstScreen?{
                sceneNode.scaleMode = .aspectFill
                return sceneNode
            }
        }
        return SKScene()
    }
    
    var body: some View {
        ZStack(alignment: .bottom){
            SpriteView(scene: scene)
            if GameController.shared.presentBar{
                ProgressBar(percentage: CGFloat(GameController.shared.barProgress))
                    .frame(height: 10)
                    .padding()
            }
        }
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView()
    }
}
