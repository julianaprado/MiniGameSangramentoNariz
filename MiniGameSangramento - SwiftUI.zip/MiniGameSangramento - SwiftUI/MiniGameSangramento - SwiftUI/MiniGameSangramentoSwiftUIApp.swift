//___FILEHEADER___

import SwiftUI

@main
struct MiniGameSangramento: App {
    var body: some Scene {
        WindowGroup {
            GameView()
        }
    }
}
