//
//  NarizScene5.swift
//  MiniGameSangramento - SwiftUI
//
//  Created by Juliana Prado on 23/11/20.
//

import Foundation
import SpriteKit
import AVFoundation

class NarizScene5: SKScene, SKPhysicsContactDelegate{

    //Player for sound
    var player: AVAudioPlayer!
    
    //emergencyCall node
    var emergencyCall: SKSpriteNode!
    
    var gameController = GameController.shared
    
    //Collision nodes
    var collision: SKSpriteNode!
    var collision2: SKSpriteNode!
    var collision3: SKSpriteNode!
    
    //Label nodes for phone
    var labelNode: SKLabelNode!
    var labelNode2: SKLabelNode!
    var labelNode3: SKLabelNode!
    
    //LabelNode with instructions
    var labelNodeIntructions: SKLabelNode!
    
    //Current node touched
    private var currentNode: SKNode?
    
    override func didMove(to view: SKView) {
        gameController.presentBar = false
        
        //Set background
        self.backgroundColor = UIColor(red: 234/275, green: 155/275, blue: 63/275, alpha: 1.0)
        
        //Initialize label with instructions
        labelNodeIntructions = SKLabelNode(fontNamed: "SF Pro Rounded")
        labelNodeIntructions.text = "Se o sangramento persistir procure ajuda médica, disque 192."
        labelNodeIntructions.position = CGPoint(x: self.size.width/2, y: self.frame.height - 60)
        labelNodeIntructions.verticalAlignmentMode = .top
        labelNodeIntructions.lineBreakMode = .byWordWrapping
        labelNodeIntructions.numberOfLines = 4
        labelNodeIntructions.fontSize = 20
        labelNodeIntructions.preferredMaxLayoutWidth = 300
        self.addChild(labelNodeIntructions)
        
        //Set physicsWorld delegate
        self.physicsWorld.contactDelegate = self
        
        
        //Initializing node with image of iPhones emergencyCall
        let emergencyCall = createSpriteNode(imageName: "emergencyCall", isDraggable: false, isRecommended: false, position: CGPoint(x: self.frame.midX + 15, y: self.frame.midY - 40), scale: 0.85, colliderType: ColliderType.finalPosition)
        self.addChild(emergencyCall)
        
        
        //Create Nodes for collision
        let collision = createCustomSpriteNode(isDraggable: false, isRecommended: false, position: CGPoint(x: 115, y: self.frame.height/1.75), scale: 0.85, colliderType: ColliderType.finalPosition)
        collision.name = "one"
        self.addChild(collision)
        
        let collision2 = createCustomSpriteNode(isDraggable: false, isRecommended: false, position: CGPoint(x: 205, y: self.frame.height/1.75), scale: 0.85, colliderType: ColliderType.finalPosition)
        collision2.name = "two"
        self.addChild(collision2)
        
        let collision3 = createCustomSpriteNode(isDraggable: false, isRecommended: false, position: CGPoint(x: 285, y: self.frame.height/2.7), scale: 0.85, colliderType: ColliderType.finalPosition)
        collision3.name = "nine"
        self.addChild(collision3)
        
    }
    
    //Check if the touch the user made was on a node and gets info of the node
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let location = touch.location(in: self)
            let touchedNodes = self.nodes(at: location)
            
            
            for node in touchedNodes.reversed(){
                if node.name == "one"{
                    labelNode = SKLabel(text: "1", position: CGPoint(x: self.size.width/3, y: self.frame.height/1.27 ))
                    self.addChild(labelNode)
                    playSound(soundName: node.name!)
                } else if node.name == "nine"{
                    labelNode = SKLabel(text: "9", position: CGPoint(x: self.size.width/2, y: self.frame.height/1.27 ))
                    self.addChild(labelNode)
                    playSound(soundName: node.name!)
                } else if node.name == "two"{
                    labelNode = SKLabel(text: "2", position: CGPoint(x: self.size.width/1.42, y: self.frame.height/1.27 ))
                    self.addChild(labelNode)
                    playSound(soundName: node.name!)
                }
            }
        }
    }
    
    //Function for playing sound
    func playSound(soundName: String) {
        let url = Bundle.main.url(forResource: soundName, withExtension: "mp3")
        player = try! AVAudioPlayer(contentsOf: url!)
        player.play()

    }
    
    //Check if the touched ended
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.currentNode = nil
    }
    
    //Set labels
    func SKLabel(text: String, position: CGPoint)->SKLabelNode{
        let mynode = SKLabelNode(fontNamed: "SF Pro Rounded")
        mynode.text = text
        mynode.position = position
        mynode.verticalAlignmentMode = .top
        mynode.lineBreakMode = .byWordWrapping
        mynode.numberOfLines = 4
        mynode.fontSize = 100
        mynode.fontColor = UIColor.black
        mynode.preferredMaxLayoutWidth = 300
        return mynode
    }
    
    func createCustomSpriteNode(imageName: String = "", isDraggable: Bool, isRecommended: Bool, position: CGPoint, scale: CGFloat = 0.30, colliderType: UInt32 = 0) -> SKSpriteNode{
        var node = SKSpriteNode(color: UIColor.clear, size: CGSize(width: 70, height: 60))
        if imageName != ""{
            node = SKSpriteNode(imageNamed: imageName)
        }
        node.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        node.setScale(scale)
        node.position = position
        node.userData = NSMutableDictionary()
        node.userData?.setValue(isDraggable, forKey: "isDraggable")
        node.name = imageName
        
        if colliderType != 0{
            if colliderType == ColliderType.movableNode{
                node.physicsBody = SKPhysicsBody(rectangleOf: node.size.applying(CGAffineTransform(scaleX: 1/6, y: 1/6)), center: CGPoint(x: 0, y: 50))
            }
            else{
                node.physicsBody = SKPhysicsBody(rectangleOf: node.size)
            }
            
            node.physicsBody?.affectedByGravity = false
            node.physicsBody?.isDynamic = true
            node.physicsBody?.categoryBitMask = colliderType
            node.physicsBody?.collisionBitMask = 0
            
            if colliderType == ColliderType.hand{
                node.physicsBody?.contactTestBitMask = ColliderType.other
            }
            else{
                node.physicsBody?.contactTestBitMask = ColliderType.hand
                node.userData?.setValue(isRecommended, forKey: "isRecommended")
            }
        }
        return node
    }
    
}
