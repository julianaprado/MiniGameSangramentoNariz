//
//  GlobalFunctions.swift
//  miniGameSangramento
//
//  Created by Juliana Prado on 09/11/20.
//

import SpriteKit


//BitMask for different nodes
struct ColliderType{
    static let finalPosition: UInt32 = 1
    static let movableNode: UInt32 = 2
    static let hand: UInt32 = 3
    static let other: UInt32 = 4
}


func createSpriteNode(imageName: String, isDraggable: Bool, isRecommended: Bool, position: CGPoint, scale: CGFloat = 1, colliderType: UInt32 = 0) -> SKSpriteNode{
    let node = SKSpriteNode(imageNamed: imageName)
    node.anchorPoint = CGPoint(x: 0.5, y: 0.5)
    node.setScale(scale)
    node.position = position
    node.userData = NSMutableDictionary()
    node.userData?.setValue(isDraggable, forKey: "isDraggable")
    node.name = imageName
    
    if colliderType != 0{
        if colliderType == ColliderType.hand{
            node.physicsBody = SKPhysicsBody(rectangleOf: node.size.applying(CGAffineTransform(scaleX: 1/4, y: 1/4)), center: CGPoint(x: 10, y: 15))
        }
        else{
            node.physicsBody = SKPhysicsBody(rectangleOf: node.size)
        }
        
        node.physicsBody?.affectedByGravity = false
        node.physicsBody?.isDynamic = true
        node.physicsBody?.categoryBitMask = colliderType
        node.physicsBody?.collisionBitMask = 0
        
        if colliderType == ColliderType.hand{
            node.physicsBody?.contactTestBitMask = ColliderType.other
        }
        else{
            node.physicsBody?.contactTestBitMask = ColliderType.hand
            node.userData?.setValue(isRecommended, forKey: "isRecommended")
        }
    }
    return node
}


func createPhysicsBody(forNode nodeName: SKNode, withColliderType colliderType: UInt32){
    if nodeName.name == "isFinalPosition"{
        nodeName.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 10, height: 10))
    } else{
        nodeName.physicsBody = SKPhysicsBody(rectangleOf: nodeName.frame.size)
    }
    
    nodeName.physicsBody?.affectedByGravity = false
    nodeName.physicsBody?.isDynamic = true
    nodeName.physicsBody?.categoryBitMask = colliderType
    nodeName.physicsBody?.collisionBitMask = 0
    
    if colliderType == ColliderType.movableNode{
        nodeName.physicsBody?.contactTestBitMask = ColliderType.finalPosition
    }
    else{
        nodeName.physicsBody?.contactTestBitMask = ColliderType.movableNode
    }
}
