//
//  GameScene.swift
//  miniGameSangramento
//
//  Created by Juliana Prado on 04/11/20.
//

import SpriteKit
import GameplayKit

class FirstScreen: SKScene, SKPhysicsContactDelegate {

    //Node that make up the form of our character
    var head: SKNode!
    var neck: SKNode!
    var shoulder: SKNode!
    var ball: SKNode!
    var torso: SKNode!

    //label node
    var labelNode: SKLabelNode!
    
    //Node for collision
    var isFinalPosition: SKNode!
    
    var gameController = GameController.shared
    
    override func didMove(to view: SKView) {
        gameController.presentBar = false
        
        self.backgroundColor = UIColor(red: 234/275, green: 155/275, blue: 63/275, alpha: 1.0)
        
        //inicializes character's body nodes and their children in their hierarchy
        torso = childNode(withName: "torso")
        ball = torso.childNode(withName: "ball")
        shoulder = ball.childNode(withName: "shoulder")
        neck = shoulder.childNode(withName: "neck")
        head = neck.childNode(withName: "head")
        
        //inicializing collision node
        isFinalPosition = childNode(withName: "isFinalPosition")
        
        torso.zPosition = 10
        
        //inicializing the labelNode with instructions
        if let label = self.childNode(withName: "labelNode") as? SKLabelNode {
            label.fontName = "SF Pro Rounded"
            label.verticalAlignmentMode = .top
            label.text = "Ponha a pessoa na posição vertical."
            label.lineBreakMode = .byWordWrapping
            label.numberOfLines = 2
            label.position = CGPoint(x: self.size.width/2, y: self.frame.height/1.20 )
            label.preferredMaxLayoutWidth = 300
        }
        
        //set physicsWorld
        self.physicsWorld.contactDelegate = self
        
        //createPhysicsBody for nodes that shall collide
        createPhysicsBody(forNode: neck, withColliderType: ColliderType.movableNode)
        createPhysicsBody(forNode: isFinalPosition, withColliderType: ColliderType.finalPosition)
    }
    
    //Allows for the user to lift the characters body, running the animation on the desired node
    func liftBodyTo(_ location: CGPoint) {
//      let liftBody = SKAction.reach(to: location, rootNode: shoulder, duration: 0.1)
//        neck.run(liftBody)
        let liftBody = SKAction.reach(to: location, rootNode: ball, duration: 0.1)
          shoulder.run(liftBody)

          if ball.zRotation < -0.66 && !location.equalTo(CGPoint(x: 30, y: 8)) {
            liftBodyTo(CGPoint(x: 90, y: 8))
              return
          }
          if ball.zRotation > 0.45  && !location.equalTo(CGPoint(x: -41, y: 41)) {
            liftBodyTo(CGPoint(x: -41, y: 41))
              return
          }
    }

    //Upon a touch event, run liftBodyTo action with the tap location as the end position
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            liftBodyTo(location)
        }
    }

    //Check if there was a contact between nodes
    func didBegin(_ contact: SKPhysicsContact) {
        if contact.bodyA.categoryBitMask == ColliderType.movableNode || contact.bodyB.categoryBitMask == ColliderType.movableNode{
            if let label = self.childNode(withName: "labelNode") as? SKLabelNode {
                label.verticalAlignmentMode = .top
                label.text = "Isso!"
                label.lineBreakMode = .byWordWrapping
                label.numberOfLines = 2
                label.preferredMaxLayoutWidth = 300
            }
            let seconds = 2.0
            DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
                let newScene = SecondScreen(fileNamed: "SecondScreen")!
                newScene.scaleMode = .aspectFill
                let transition = SKTransition.fade(with: SKColor.black, duration: 0.5)
                self.view?.presentScene(newScene, transition: transition)
            }
        }
    }
}

//MARK: - SKNode Position
extension SKNode{
    public var scaleAsSize: CGSize {
     get {
        return frame.size
     }
     set {
       xScale = newValue.width/frame.size.width
       yScale = newValue.height/frame.size.height
     }
   }
}
