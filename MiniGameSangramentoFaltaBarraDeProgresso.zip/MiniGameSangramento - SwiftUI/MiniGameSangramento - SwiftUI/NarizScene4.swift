//
//  FourthScreen.swift
//  MiniGameSangramento - SwiftUI
//
//  Created by Juliana Prado on 19/11/20.
//

import Foundation
import SpriteKit

class NarizScene4: SKScene, SKPhysicsContactDelegate{
    //Nose node
    var nose: SKSpriteNode!
  
    //label node
    var labelNode: SKLabelNode!
    
    //Ice node
    var handHoldingIce: SKSpriteNode!
    
    //Default position of the current touched node
    private var defaultPosition: CGPoint?
    
    //Current node touched
    private var currentNode: SKNode?
    
    //Checks if the objects have been contacting for a second
    var delta = 0.0
    
    //Check if the objects have been contacting
    var isContacting = false
    
    var gameController = GameController.shared
    
    override func didMove(to view: SKView) {
        gameController.presentBar = true
        gameController.actionFinished = false
        
        self.backgroundColor = UIColor(red: 175/275, green: 135/275, blue: 105/275, alpha: 1.0)
        
        let nose = createSpriteNode(imageName: "nose", isDraggable: false, isRecommended: false, position: CGPoint(x: self.frame.midX, y: self.frame.midY), scale: 0.70, colliderType: ColliderType.finalPosition)
        self.addChild(nose)
        
        let handHoldingIce = createCustomSpriteNode(imageName: "ice", isDraggable: true, isRecommended: false, position: CGPoint(x: self.frame.midX/2, y: self.frame.midY/3), colliderType: ColliderType.movableNode)
        self.addChild(handHoldingIce)
        
        self.physicsWorld.contactDelegate = self
        
        //setting up labelNode
        labelNode = SKLabelNode(fontNamed: "SF Pro Rounded")
        labelNode.text = "Aplique gelo na ponta do nariz, mas não por mais que 5 minutos!"
        labelNode.position = CGPoint(x: self.size.width/2, y: self.frame.height/1.20 )
        labelNode.verticalAlignmentMode = .top
        labelNode.fontColor = UIColor.black
        labelNode.lineBreakMode = .byWordWrapping
        labelNode.fontSize = 26
        labelNode.numberOfLines = 4
        labelNode.preferredMaxLayoutWidth = 300
        self.addChild(labelNode)
    }
    
    //Check if the touch the user made was on a node and gets info of the node
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let location = touch.location(in: self)
            let touchedNodes = self.nodes(at: location)
            
            for node in touchedNodes.reversed(){
                if let nodeTmp = node as? SKObject{
                    if nodeTmp.isDraggable{
                        self.defaultPosition = node.position
                        self.currentNode = node
                    }
                }
                
                if node.userData?.value(forKey: "isDraggable") as? Bool == true{
                    utilities.removeActions(nodes: self.children)
                    self.defaultPosition = node.position
                    self.currentNode = node
                }
            }
        }
    }
    
    //Check if the user is dragging the node and updates its location
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first, let node = currentNode {
            let touchLocation = touch.location(in: self)
            node.position = touchLocation
        }
    }
    
    //Check if the touched ended
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.currentNode?.position = self.defaultPosition ?? CGPoint(x: 0, y: 0)
        self.isContacting = false
        gameController.barProgress = 0
        self.currentNode = nil
    }
    
    //Check if the user stopped touching before completing the action
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.currentNode?.position = self.defaultPosition ?? CGPoint(x: 0, y: 0)
        self.currentNode = nil
    }
    
    //Check if there was a contact between nodes
    func didBegin(_ contact: SKPhysicsContact) {
       // GameController.shared.barProgress = true
        if contact.bodyA.categoryBitMask == ColliderType.movableNode || contact.bodyB.categoryBitMask == ColliderType.movableNode{
            print("Contact Detected")
            self.isContacting = true
        }
    }
    
    //Check if the contact ended
    func didEnd(_ contact: SKPhysicsContact) {
        if contact.bodyA.categoryBitMask == ColliderType.movableNode || contact.bodyB.categoryBitMask == ColliderType.movableNode{
            print("Contact Ended")
            self.isContacting = false
            gameController.barProgress = 0
        }
    }
    
    
    //Called everytime to update variables values
    override func update(_ currentTime: TimeInterval) {
        if self.isContacting && !gameController.actionFinished{
            if gameController.barProgress >= 100 {
                gameController.barProgress = 0
                gameController.presentBar = false
                gameController.presentPopup = true
                gameController.actionFinished = true
                
                labelNode.text = "Isso!"
                
                let seconds = 2.0
                //Calling next scene
                DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
                    let goToNextScene = NarizScene5(size: self.size)
                    goToNextScene.scaleMode = .aspectFill
                    let transition = SKTransition.fade(with: SKColor.black, duration: 0.5)
                    self.view?.presentScene(goToNextScene, transition: transition)
                }
                
            }
            else{
                gameController.barProgress += 20
            }
        }
    }
    
    func createCustomSpriteNode(imageName: String, isDraggable: Bool, isRecommended: Bool, position: CGPoint, scale: CGFloat = 0.30, colliderType: UInt32 = 0) -> SKSpriteNode{
        let node = SKSpriteNode(imageNamed: imageName)
        node.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        node.setScale(scale)
        node.position = position
        node.userData = NSMutableDictionary()
        node.userData?.setValue(isDraggable, forKey: "isDraggable")
        node.name = imageName
        
        if colliderType != 0{
            if colliderType == ColliderType.movableNode{
                node.physicsBody = SKPhysicsBody(rectangleOf: node.size.applying(CGAffineTransform(scaleX: 1/6, y: 1/6)), center: CGPoint(x: 0, y: 50))
            }
            else{
                node.physicsBody = SKPhysicsBody(rectangleOf: node.size)
            }
            
            node.physicsBody?.affectedByGravity = false
            node.physicsBody?.isDynamic = true
            node.physicsBody?.categoryBitMask = colliderType
            node.physicsBody?.collisionBitMask = 0
            
            if colliderType == ColliderType.hand{
                node.physicsBody?.contactTestBitMask = ColliderType.other
            }
            else{
                node.physicsBody?.contactTestBitMask = ColliderType.hand
                node.userData?.setValue(isRecommended, forKey: "isRecommended")
            }
        }
        return node
    }
    
    
}
