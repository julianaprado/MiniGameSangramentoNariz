//
//  ProgressBar.swift
//  CortesScene
//
//  Created by Vitor Krau on 08/11/20.
//

import SwiftUI

struct ProgressBar: View {
    var percentage: CGFloat
    var body: some View {
        ZStack{
            GeometryReader{ geometry in
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(width: geometry.size.width)
                RoundedRectangle(cornerRadius: 15)
                    .foregroundColor(.red)
                    .frame(width: (self.percentage * geometry.size.width) / 100)
                    .animation(.linear(duration: 1.0))
                
            }
        }
    }
}

struct ProgressBar_Previews: PreviewProvider {
    static var previews: some View {
        ProgressBar(percentage: 50)
            .frame(height: 10)
    }
}
