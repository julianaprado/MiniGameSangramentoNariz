//
//  GameView.swift
//  miniGameSangramento
//
//  Created by Vitor Krau on 19/11/20.
//

import SwiftUI
import SpriteKit
import GameplayKit

struct GameView: View {
    
 //   @ObservedObject var gameController = GameController.shared
    
    var scene: SKScene{
        if let scene = GKScene(fileNamed: "FirstScreen"){
            if let sceneNode = scene.rootNode as! FirstScreen?{
                sceneNode.size = UIScreen.main.bounds.size
                sceneNode.scaleMode = .aspectFill
                return sceneNode
            }
        }
        return SKScene()
    }
    
    var body: some View {
        ZStack(alignment: .bottom){
            SpriteView(scene: scene)
                .edgesIgnoringSafeArea(.all)
     //       if gameController.presentBar{
      //          ProgressBar(percentage: CGFloat(gameController.barProgress))
      //              .frame(height: 10)
       //             .padding()
        //    }
        }
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView()
    }
}
